# PlayerShotsPlotted


![image](https://user-images.githubusercontent.com/37336594/182237522-5ddd33e1-6c88-4941-b08b-e0d9bae0e2b6.png)

